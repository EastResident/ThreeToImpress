sample = function(){
	alert("hello");
};
